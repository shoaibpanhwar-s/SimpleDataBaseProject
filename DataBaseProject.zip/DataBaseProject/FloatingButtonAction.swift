//
//  FloatingButtonAction.swift
//  shoaibdesign
//
//  Created by spkamran on 26/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class FloatingButtonAction: UIButtonX {

    override func beginTracking(_ touch: UITouch, with event: UIEvent?) -> Bool {
        UIView.animate(withDuration: 0.4, animations: {
        
            if self.transform == .identity{
                let angleRotate:Double = 45 * .pi/180 ;
                self.transform = CGAffineTransform(rotationAngle: CGFloat(angleRotate))
               
                              
                //  self.backgroundColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
                
            }
            else {  self.transform = .identity
            
            self.backgroundColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
            }
        
        })
        return super.beginTracking(touch, with: event)
    }
    

}

    
