//
//  tableViewController.swift
//  DataBaseProject
//
//  Created by spkamran on 06/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit





class tableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var table: UITableView!
    
    var arr:NSMutableArray = NSMutableArray()
   
 
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        table.delegate = self
        table.dataSource = self
        
        arr = DataBaseManager.getInstance().GetValues()
        table.reloadData()
        

        
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        var passdata:DBMOdul = DBMOdul()
        passdata = arr.object(at: indexPath.row) as! DBMOdul
        cell.ID.text! = String(passdata.P_ID)
        cell.namelbl.text! = passdata.Name
        cell.surnamelbl.text! = passdata.Address
        cell.citylbl.text! = passdata.Bill
        
       return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var passdata:DBMOdul = DBMOdul()
        passdata = arr.object(at: indexPath.row) as! DBMOdul
        
        let through = self.storyboard?.instantiateViewController(withIdentifier: "ShowData") as! ShowDataViewController
        
        through.passData4 = passdata.P_ID
        through.passDatalb = passdata.Name
        through.passDatalb2 = passdata.Address
        through.passDatalb3 = passdata.Bill
        
        
        
        present(through, animated:  true, completion:  nil)
        

        
    }
    
    @IBAction func BackToInsertionPage(_ sender: UIButton) {
        
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "Main1Story")
        
                present(pass!, animated:  true, completion:  nil)
        
        
        
    }
    
    
    
    
    
    
    
    
//    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
//        
//        
//            if editingStyle == .delete{
//               
//                DataBaseManager.getInstance().del()
//                    arr.remove(at: indexPath.row)
//                    
//        }//if
//    }//commit

    
}
