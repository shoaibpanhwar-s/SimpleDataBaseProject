//
//  CreatTableViewController.swift
//  DataBaseProject
//
//  Created by spkamran on 28/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class CreatTableViewController: UIViewController {

   
    @IBOutlet var ColumnsCollectionText: [UITextField]!

    
    
    @IBOutlet var FieldTypeTextCollection: [UITextField]!
    
    @IBOutlet weak var TableName: UITextField!
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    @IBAction func CreatActionButton(_ sender: UIButton) {
        
        
        let create:DBMOdul = DBMOdul()
        
        create.creat = TableName.text!
        
        
        
                create.Column1 = ColumnsCollectionText[0].text!
                create.Text1 = FieldTypeTextCollection[0].text!
        
        create.Column2 = ColumnsCollectionText[1].text!
       


        
        
        let cr = DataBaseManager.getInstance().createTable(create)
        
        if cr{
            print("table createeddd")
            
        }
        else{ print("not createee") }
        

                

//        create.Column1 = ColumnsCollectionText[0].text!
//        create.Text1 = FieldTypeTextCollection[0].text!
////        create.Column2 = ColumnsCollectionText[1].text!
//        create.Text2 = FieldTypeTextCollection[1].text!
//        create.Column3 = ColumnsCollectionText[2].text!
//        create.Text3 = FieldTypeTextCollection[2].text!
//        create.Column4 = ColumnsCollectionText[3].text!
//        create.Text4 = FieldTypeTextCollection[3].text!
//        create.Column5 = ColumnsCollectionText[4].text!
//        create.Text5 = FieldTypeTextCollection[4].text!
//        create.Column6 = ColumnsCollectionText[5].text!
//        create.Text6 = FieldTypeTextCollection[5].text!
//        create.Column7 = ColumnsCollectionText[6].text!
//        create.Text7 = FieldTypeTextCollection[6].text!
//        create.Column8 = ColumnsCollectionText[7].text!
//        create.Text8 = FieldTypeTextCollection[7].text!
//        create.Column9 = ColumnsCollectionText[8].text!
//        create.Text9 = FieldTypeTextCollection[8].text!
//        create.Column10 = ColumnsCollectionText[9].text!
//        create.Text10 = FieldTypeTextCollection[9].text!
//        
//        
        
        
        
        
//        let getDBPath = DataBaseManager.getInstance().createTable(create)
//        
//        
//        if getDBPath {
//            
//            print("table created")
//            
//        }
//        else{ print(" Table not create")
//        
//        }
//        
//        
//        
//        
//        
        
    }
}
