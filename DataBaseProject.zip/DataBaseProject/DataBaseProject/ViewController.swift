//
//  ViewController.swift
//  DataBaseProject
//
//  Created by spkamran on 01/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit


class ViewController: UIViewController {//class

    var GetAllDataInfo = NSMutableArray()
    
    @IBOutlet weak var secondView: UIView!
    
    @IBOutlet weak var Name: UITextField!
    
    @IBOutlet    var Surname: UITextField!
    
    @IBOutlet weak var City: UITextField!
    
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var createTextt: UITextField!
    
   // let array:NSMutableArray = NSMutableArray()
    
    
    
    override func viewDidLoad() {// didload method
        super.viewDidLoad()
   // _ = DataBaseManager.getInstance().updateRecode()
   // _ = DataBaseManager.getInstance().delete()
        
    }//didload method


    @IBAction func SaveDataBTn(_ sender: UIButton) {
        
        let insert:DBMOdul = DBMOdul()
        
        insert.Name = Name.text!
        insert.Address = Surname.text!
        insert.Bill = City.text!
        
      let saved = DataBaseManager.getInstance().saveData(insert)
        
       // print("Data inserted")
        if saved{
        //print("Data Is Saved", saved)
            
            let alrt = UIAlertController(title: "Data Saved", message: " " , preferredStyle: .alert)
            alrt.addAction(UIAlertAction(title: "OK", style: .default))
            
            present(alrt, animated: true, completion: nil)
        
        }
        else{
        
        print("data is not saved")
        }
       Name.text = ""
        Surname.text = ""
        City.text = ""
        
   

    }
    
    @IBAction func Home(_ sender: UIButton) {
        
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "MainStory")
        
        present(pass!, animated:  true, completion:  nil)
        
    }
    @IBAction func showdata(_ sender: UIButton) {
        
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "datatable")
        
        present(pass!, animated:  true, completion:  nil)
        
   }

    }//class

