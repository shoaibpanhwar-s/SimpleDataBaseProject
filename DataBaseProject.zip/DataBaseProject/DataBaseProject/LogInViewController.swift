//
//  LogInViewController.swift
//  shoaibdesign
//
//  Created by spkamran on 27/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class LogInViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var UserText: UITextField!
 
    @IBOutlet weak var PasswordText: UITextField!
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        UserText.delegate = self
        PasswordText.delegate = self
        
    
        
        addLeftImageTo(textField: UserText, andImage: #imageLiteral(resourceName: "user"))
        
        addLeftImageTo(textField: PasswordText, andImage: #imageLiteral(resourceName: "16205-200"))
        
       // UserText.text = "\(date)"
        
    }
    
    func addLeftImageTo(textField: UITextField, andImage imgg: UIImage){ //set size and show img on text field method start
        
        let leftimg = UIImageView(frame: CGRect(x: 0, y:0, width: 35, height: 35))
        
        leftimg.image = imgg
        
        textField.leftView = leftimg
        
        textField.leftViewMode = .always
        
        
    }////set size
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        view.endEditing(true)
        return true
    }

    
    @IBAction func LoginButton(_ sender: UIButton) {
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "MainStory")
        
    present(pass!, animated:  true, completion:  nil)
    
       
    }

    
        
    
    
    

 
}
