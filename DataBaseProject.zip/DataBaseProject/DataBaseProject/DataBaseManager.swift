

import Foundation
import UIKit

var ShareInstance:DataBaseManager = DataBaseManager()

class DataBaseManager:NSObject{ //class nsobject

    
    

    
    var database:FMDatabase? = nil
   
    
    class func getInstance() -> DataBaseManager{
       
        if ShareInstance.database == nil{
            ShareInstance.database = FMDatabase(path: ConnectionDB.getPath("Hospital.db"))
        }
        return ShareInstance
    }

    
  
    
    
    
    func saveData(_ modelInfo:DBMOdul) -> Bool {
        
        ShareInstance.database?.open()
        let isSave = ShareInstance.database?.executeUpdate("INSERT INTO Ward (name,Address,Bill) VALUES (?,?,?)", withArgumentsIn: [modelInfo.Name,modelInfo.Address,modelInfo.Bill])
        ShareInstance.database?.close()
        return isSave!
    }
    
    
    func GetValues() -> NSMutableArray {
       
        ShareInstance.database!.open()
        
        let resultSet:FMResultSet! = ShareInstance.database!.executeQuery("SELECT * FROM Ward", withArgumentsIn: [0])
       
        let info:NSMutableArray = NSMutableArray()
       
        
        if (resultSet != nil){//if
            while resultSet.next() {//while
            
            
                let itemm:DBMOdul = DBMOdul()
                
                itemm.P_ID = resultSet.string(forColumn: "P_ID")!
                itemm.Name = resultSet.string(forColumn: "Name")!
                itemm.Address = resultSet.string(forColumn: "Address")!
                itemm.Bill = resultSet.string(forColumn: "Bill")!
                
            
            info.add(itemm)
            
            
            
            
        }//while
        }//if
        
        
        ShareInstance.database!.close()
   return info
    
    }//getvalue
    
    func del(id:Int){
    
        ShareInstance.database!.open()
        
        
        
        do {
            try ShareInstance.database!.executeUpdate("delete from ward where P_ID = ?", values: [id])
            
        } catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        
        
        
        
        
        
        ShareInstance.database!.close()
        
        
        
    
    }
    
    
}//ns object

