//
//  ShowDataViewController.swift
//  DataBaseProject
//
//  Created by spkamran on 07/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class ShowDataViewController: UIViewController {
 
    @IBOutlet weak var rollnumber: UITextField!

    @IBOutlet weak var DeleteOutl: UIButton!
    
    @IBOutlet weak var upd: UIButton!
    
    
    @IBOutlet weak var Name: UITextField!
    
    @IBOutlet weak var Surname: UITextField!
    
    
    @IBOutlet weak var cityy: UITextField!
    
    
    var passDatalb:String = ""
    
    var passDatalb2:String = ""
    
    var passDatalb3:String = ""
    
    var passData4:String = ""
    
    override func viewDidLoad() {
          super.viewDidLoad()

        
        Name.text! = passDatalb
        
        Surname.text! = passDatalb2
        
        cityy.text! = passDatalb3
        
        rollnumber.text! = passData4
            
            //String(passData4) //parsing from int to string

        
        
        // Do any additional setup after loading the view.
   
    
    }

    
    @IBAction func deleteacrion(_ sender: UIButton) {
        
        ShareInstance.database!.open()
        
        
        
        do {
        try ShareInstance.database!.executeUpdate("delete from ward where P_ID = ?", values: ["\(rollnumber.text!)"])
            
        } catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        
    
   ShareInstance.database!.close()
   
        
        
        Name.text! = ""
        Surname.text!  = ""
        cityy.text!  = ""
        rollnumber.text!  = ""
        
        
        let alrt = UIAlertController(title: "Recode Deleted", message: " " , preferredStyle: .alert)
       
        alrt.addAction(UIAlertAction(title: "OK", style: .default))
        
        present(alrt, animated: true, completion: nil)
        
        
        
        
    }

    @IBAction func updaction(_ sender: UIButton) {
        
      //  _ = DataBaseManager.getInstance().updateRecode()
        
        ShareInstance.database!.open()
        
        
        
        do {
            try ShareInstance.database!.executeUpdate("update ward set name = ?, Address = ? , Bill = ? where P_ID = ? ", values: ["\(Name.text!)", "\(Surname.text!)","\(cityy.text!)","\(rollnumber.text!)"])
            
        } catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        
        
        
        
        
        
        ShareInstance.database?.close()
        
        
        
        
        
        passDatalb = ""
        passDatalb2 = ""
        cityy.text!  = ""
        passData4 = ""
        
        
        let alrt = UIAlertController(title: "Recode Updated", message: " " , preferredStyle: .alert)
       
        alrt.addAction(UIAlertAction(title: "OK", style: .default))
        
        present(alrt, animated: true, completion: nil)
        
        
        

        
        
        
    }
    
    
    
    @IBAction func GOTsble(_ sender: Any) {
        
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "datatable")
        
                present(pass!, animated:  true, completion:  nil)
        
        
        
    }
    
    
    
    

}
