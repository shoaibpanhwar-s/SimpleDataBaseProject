//
//  AnimatedTableViewCell.swift
//  DataBaseProject
//
//  Created by spkamran on 28/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class AnimatedTableViewCell: UITableViewCell {

    
    @IBOutlet weak var cellimage: UIImageView!
    
    @IBOutlet weak var Titlelbl1: UILabel!
    
    
    @IBOutlet weak var subTitlelbl1: UILabel!
    
    @IBOutlet weak var Data1lbl: UILabel!
    
    @IBOutlet weak var Data2lbl2: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
