//
//  TableViewCell.swift
//  DataBaseProject
//
//  Created by spkamran on 06/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var ID: UILabel!
    
    @IBOutlet weak var namelbl: UILabel!
    
    
    @IBOutlet weak var citylbl: UILabel!
    
    @IBOutlet weak var surnamelbl: UILabel!
    
    @IBOutlet weak var CellImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
