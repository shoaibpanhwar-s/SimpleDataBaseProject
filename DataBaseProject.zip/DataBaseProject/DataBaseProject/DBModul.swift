

import Foundation
import UIKit
class DBMOdul:NSObject{ // model class
     
    
    var P_ID:String = String()
    var Name:String = String()
    var Address:String = String()
    var Bill:String = String()
 
 
}//model class

