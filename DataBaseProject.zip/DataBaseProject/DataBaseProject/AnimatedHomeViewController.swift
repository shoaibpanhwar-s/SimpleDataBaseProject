import UIKit

class AnimatedHomeViewController: UIViewController, UITextFieldDelegate,  UITableViewDelegate, UITableViewDataSource  {
    
    
    @IBOutlet weak var DayyView: UIView!
    
    @IBOutlet weak var WeatherView: UIView!
    
    @IBOutlet weak var PlusView: UIViewX!
    
    
    @IBOutlet weak var PenButton: UIButton!
    
    
    @IBOutlet weak var pageButton: UIButton!
    
    
    @IBOutlet weak var AlarmButton: UIButton!
    
    @IBOutlet weak var plusButton: FloatingButtonAction!
    
    @IBOutlet weak var SideBarView: UIViewX!
    
    @IBOutlet weak var sidebutton: UIButton!
    
    @IBOutlet weak var searchbutton: UITextField!
    
    
    let array = ["shoaib","panhwar","mpk","sindh"]//label arry
    let array2 = [#imageLiteral(resourceName: "golden bridge")]// img array
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        close ()
        setupAnimationControlls()//setup label weather and day view animation
        // animateTableViewCell() //animation of cells using loop
        
        
        
        
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array2.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell =  tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AnimatedTableViewCell
        
        
        
        cell.cellimage.image = array2[indexPath.row]
        
        cell.Titlelbl1.text = array[indexPath.row]
        cell.subTitlelbl1.text = array[indexPath.row]
        cell.Data1lbl.text = array[indexPath.row]
        cell.Data2lbl2.text = array[indexPath.row]
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) { //for cell animation
        
        
        
        
        
        cell.alpha = 0
        //transform from position            //come from X-Axis left    this is center Y      //end point
        let tranform = CATransform3DTranslate(CATransform3DIdentity, -250,      0,             0)
        cell.layer.transform = tranform
        //simple animation table will show after 2 sec
        UIView.animate(withDuration: 0.7){
            cell.layer.transform = CATransform3DIdentity
            cell.alpha = 2.0
            
        }
        
        
        
    }
    
    @IBAction func PlusButtonActionFloat(_ sender: UIButton) {
        
        
        
                print("hello")
        
                UIView.animate(withDuration: 0.3, animations: {
        
                    if self.PlusView.transform == .identity{
        
                        self.close ()
        
        
        
                    }
                    else{ self.PlusView.transform = .identity   }
        
        
        
        
        
        
                })
        
                //animation jumping button or damping
                UIView.animate(withDuration: 0.4, delay: 0.3, usingSpringWithDamping: 0.3, initialSpringVelocity: 0, options: [], animations: {
        
                    if self.PlusView.transform == .identity{
        
                        self.PenButton.transform = .identity//jumping animation
                        self.pageButton.transform = .identity
                        self.AlarmButton.transform = .identity
                        
                        
                        
                    }
                    
                    
                })
                
                
                
        
        
        
        
        
        
        
    }
    
    
    
    
    
    func close (){
        self.PlusView.transform = CGAffineTransform(scaleX: 0.0, y: 0.0)
        //right         down
        PenButton.transform = CGAffineTransform(translationX: 0, y: 20)
        
        pageButton.transform = CGAffineTransform(translationX: 11, y: 11)
        
        AlarmButton.transform = CGAffineTransform(translationX: 15, y: 11)
        
        
        
    }
    
    
    func setupAnimationControlls(){
        
        DayyView.transform = CGAffineTransform(translationX: -DayyView.frame.width  , y: 0 ) //left positoion
        
        WeatherView.transform = CGAffineTransform(translationX: WeatherView.frame.width  , y: 0 ) //Right positoion
        
        
        
        
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        
        UIView.animate(withDuration: 0.5, delay: 0.5, usingSpringWithDamping: 0.3, initialSpringVelocity: 0, options: [], animations: {
            self.DayyView.transform = .identity
            self.WeatherView.transform = .identity
            
        }){ (success) in }
        
    }
    
    @IBAction func SideBarMenuButton(_ sender: UIButton) {
    
    
        UIView.animate(withDuration: 0.5, animations: {
            
            if self.SideBarView.transform == .identity{
                
                self.SideBarView.transform = CGAffineTransform(translationX: 220, y: 0)
                self.sidebutton.transform = CGAffineTransform(translationX: 220, y: 0 )
                
                
            }
                
            else{ self.SideBarView.transform = .identity
                
                self.sidebutton.transform = .identity
            }
            
        })
        //
   
    
    }
    
    @IBAction func SignOut(_ sender: UIButton) {
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "LogInStory")
        
            present(pass!, animated:  true, completion:  nil)
        
        
        
    }
    
    @IBAction func InsertionData(_ sender: UIButton) {
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "Main1Story")
        
                present(pass!, animated:  true, completion:  nil)
        
        
    }
    @IBAction func CreatTableView(_ sender: Any) {
        
//        let pass = self.storyboard?.instantiateViewController(withIdentifier: "TableCreateStory")
//        
//        present(pass!, animated:  true, completion:  nil)
//        
//        

        
    }
    
    
    
    
    @IBAction func searchButton(_ sender: Any) {
//        
//        UIView.animate(withDuration: 0.5, animations: {
//            
//            if self.searctextt.transform == .identity {
//                self.searctextt.transform = CGAffineTransform(translationX: 220, y: 0)
//            }
//                
//            else{ self.searctextt.transform = .identity
//                
//                // self.sidebutn.transform = .identity
//            }
//            
//        })    }

    }

}//class
